﻿
        Install 'zazanaire.setup 4.0.exe'.
        Open any template file in 'templates' folder to start with.
        Reference http://slideshowmaker.jssor.com


        Note that the software 'zazanaire' runs on windows system with .NET 2.0 installed.


        Resources:
        Top Wordpress Templates http://themeforest.net/popular_item/by_category?ref=jssor&category=wordpress
        Top Site Templates http://themeforest.net/popular_item/by_category?ref=jssor&category=site-templates